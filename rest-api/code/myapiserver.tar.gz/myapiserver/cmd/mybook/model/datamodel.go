package model

import "time"

//json for error response
type ErrorResponse struct {
	ErrorMsg string `json:"message"`
}

//book data to keep
type MyBook struct {
	BookId string `json:"bookId"`
	Title string `json:"title"`
	Author string `json:"author"`
}

//base API template structure
type APIResponse struct {
	Timestamp  time.Time   `json:"timestamp"`
	StatusCode int         `json:"statusCode"`
	Data       interface{} `json:"data"`  // value in this field is accept any type of data
}