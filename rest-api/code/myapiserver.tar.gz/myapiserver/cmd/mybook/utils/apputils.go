package utils

import (
	"myapiserver/cmd/mybook/model"
	"strings"
)

func SearchBook(bookId string, bookCollection []model.MyBook) (book *model.MyBook, index int) {
	for idx, book := range bookCollection {
		if strings.Compare(bookId, book.BookId) == 0 {
			return &book, idx
		}
	}
	return nil, -1
}