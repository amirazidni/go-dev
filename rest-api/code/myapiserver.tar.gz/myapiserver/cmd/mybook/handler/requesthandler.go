package handler

import (
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"myapiserver/cmd/mybook/model"
	"myapiserver/cmd/mybook/utils"
	"net/http"
	"strconv"
	"time"
)

//limit book to keep
const TotalBookRows = 5

//book collection place holder, need to initialize
var bookCollection = make([]model.MyBook, 0)

func RequestHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet :
		RequestGetHandler(w, r)
	case http.MethodPost:
		RequestPostHandler(w, r)
	case http.MethodPut :
		RequestPutHandler(w, r)
	case http.MethodDelete:
		RequestDeleteHandler(w, r)
	}
}

//handler get method
func RequestGetHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("receive request with method:  %s\n", r.Method)
	fmt.Printf("requester address: %s\n",r.RemoteAddr)

	//send response success
	responseWriter(w, http.StatusOK, bookCollection)

	fmt.Printf("done handling request %s\n", r.Method)
}

//handler get method with bookid param
func RequestGetParamHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("receive request with method:  %s using bookid parameter\n", r.Method)
	fmt.Printf("requester address: %s\n",r.RemoteAddr)

	vars := mux.Vars(r)
	bookid := vars["bookid"]
	book, _ := utils.SearchBook(bookid, bookCollection)
	if book != nil {
		responseWriter(w, http.StatusOK, book)
	} else {
		errBody := model.ErrorResponse{
			ErrorMsg: fmt.Sprintf("Book with id %s not found", bookid),
		}
		responseWriter(w, http.StatusBadRequest, errBody)
	}

	fmt.Printf("done handling request %s\n", r.Method)
}

//handler post method
func RequestPostHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("receive request with method:  %s\n", r.Method)
	fmt.Printf("requester address: %s\n",r.RemoteAddr)

	//convert body request into request struct book data model
	var requestDataModel model.MyBook
	jsonDecoder := json.NewDecoder(r.Body)
	err := jsonDecoder.Decode(&requestDataModel)
	if err != nil {
		fmt.Printf("failed to decode json request body: %+v\n", err)
		panic(err)
	}
	fmt.Printf("successfully decode json request body into struct \n")

	//verify if book already exist or not
	book, _ := utils.SearchBook(requestDataModel.BookId, bookCollection)

	if book != nil {
		//build error body response
		errBody := model.ErrorResponse{
			ErrorMsg: fmt.Sprintf("Book with id %s already exists", requestDataModel.BookId),
		}
		//send response error
		responseWriter(w, http.StatusConflict, errBody)
		return //force return to make sure code below not executed
	}

	//build json response payload
	if len(bookCollection) < TotalBookRows { //build success response
		bookCollection = append(bookCollection, requestDataModel)

		//send response success
		responseWriter(w, http.StatusOK, bookCollection)
	} else { //build error response

		//build error body response
		errBody := model.ErrorResponse{
			ErrorMsg: "Book collection is exceed! cannot add more book",
		}

		//send response error
		responseWriter(w, http.StatusNotAcceptable, errBody)
	}
	fmt.Printf("done handling request %s\n", r.Method)
}

//handler put method
func RequestPutHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("receive request with method:  %s\n", r.Method)
	fmt.Printf("requester address: %s\n",r.RemoteAddr)

	//convert body request into request struct book data model
	var requestDataModel model.MyBook
	jsonDecoder := json.NewDecoder(r.Body)
	err := jsonDecoder.Decode(&requestDataModel)
	if err != nil {
		fmt.Printf("failed to decode json request body: %+v\n", err)
		panic(err)
	}
	fmt.Printf("successfully decode json request body into struct \n")

	//check if book already exists or not, if exist then update else append to bookCollection
	book, idx := utils.SearchBook(requestDataModel.BookId, bookCollection)

	//verifying book collection space
	if len(bookCollection) < TotalBookRows {
		if book == nil { // book not exists, then append it to collection
			bookCollection = append(bookCollection, requestDataModel)
		} else {
			//book found, then update book collection info
			bookCollection[idx].Title = requestDataModel.Title
			bookCollection[idx].Author = requestDataModel.Author
		}

		//send response success
		responseWriter(w, http.StatusOK, bookCollection)

	} else if len(bookCollection) == TotalBookRows {
		if book == nil {
			//book not exists, we want to append it into collection
			//but there is no more space to keep book, then return error response
			//build error body response
			errBody := model.ErrorResponse{
				ErrorMsg: "Book collection is exceed! cannot add more book",
			}

			//send response error
			responseWriter(w, http.StatusNotAcceptable, errBody)
			fmt.Printf("done handling request %s", r.Method)
			return //must call return, if not code below will be executed
		}

		//book found, then update book collection info
		bookCollection[idx].Title = requestDataModel.Title
		bookCollection[idx].Author = requestDataModel.Author

		//send response success
		responseWriter(w, http.StatusOK, bookCollection)
	}
	fmt.Printf("done handling request %s\n", r.Method)
}

//handler delete method
func RequestDeleteHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("receive request with method:  %s\n", r.Method)
	fmt.Printf("requester address: %s\n",r.RemoteAddr)

	//convert body request into request struct book data model
	var requestDataModel model.MyBook
	jsonDecoder := json.NewDecoder(r.Body)
	err := jsonDecoder.Decode(&requestDataModel)
	if err != nil {
		fmt.Printf("failed to decode json request body: %+v\n", err)
		panic(err)
	}
	fmt.Printf("successfully decode json request body into struct \n")

	//search and remove from book index collection
	book, idx := utils.SearchBook(requestDataModel.BookId, bookCollection)

	if book == nil { //not found
		//build error body response
		errBody := model.ErrorResponse{
			ErrorMsg: fmt.Sprintf("Book id %s not found or is already deleted", requestDataModel.BookId),
		}

		//send response error
		responseWriter(w, http.StatusGone, errBody)
		fmt.Printf("done handling request %s", r.Method)
	} else { // found target for remove index
		//rebuild slice except index in "idx" variable
		bookCollection = append(bookCollection[:idx], bookCollection[idx+1:]...)

		//send response success
		responseWriter(w, http.StatusOK, bookCollection)
	}
	fmt.Printf("done handling request %s\n", r.Method)
}

//response builder using APIResponse template
func responseWriter(w http.ResponseWriter, statusCode int, data interface{}) ([]byte, int) {

	//set desired header, it is optional to set
	w.Header().Set("Content-type","application/json")                          //optional
	w.Header().Set("Total-book-collection", strconv.Itoa(len(bookCollection))) //optional

	//set http response code
	w.WriteHeader(statusCode)

	//build response body template and pass data value
	responseTemplate := model.APIResponse{
		Timestamp : time.Now(),
		StatusCode : statusCode,
		Data : data,
	}

	//write to requester
	if data != nil {
		jsonResponseByte, _ := json.Marshal(responseTemplate)
		fmt.Printf("sending json response : %s\n", string(jsonResponseByte))
		w.Write(jsonResponseByte)
		return jsonResponseByte, statusCode
	} else {
		fmt.Println("sending empty body response")
		w.Write(nil)
		return nil, statusCode
	}

}