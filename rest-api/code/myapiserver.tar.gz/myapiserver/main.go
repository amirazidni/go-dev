package main

import (
	"fmt"
	"github.com/gorilla/mux"
	"log"
	"myapiserver/cmd/mybook/handler"
	"net/http"
	"time"
)

func main () {

	//create gorilla mux router
	router := mux.NewRouter()

	//define http service options
	srvOptions := &http.Server{
		Addr:         fmt.Sprintf("0.0.0.0:%s", "8000"),
		WriteTimeout: time.Second * 5,
		ReadTimeout:  time.Second * 5,
		IdleTimeout:  time.Second * 5,
		Handler:      router,
	}

	//register handler
	router.HandleFunc("/book",handler.RequestGetHandler).Methods(http.MethodGet)
	router.HandleFunc("/book/{bookid}",handler.RequestGetParamHandler).Methods(http.MethodGet)
	router.HandleFunc("/book",handler.RequestPostHandler).Methods(http.MethodPost)
	router.HandleFunc("/book",handler.RequestPutHandler).Methods(http.MethodPut)
	router.HandleFunc("/book",handler.RequestDeleteHandler).Methods(http.MethodDelete)

	//start server
	log.Fatal(srvOptions.ListenAndServe())
}